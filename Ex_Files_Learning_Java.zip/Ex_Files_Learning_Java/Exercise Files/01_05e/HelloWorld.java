public class HelloWorld {
	
	public static void main(String[] args) {
		System.out.println("Hello World! It's me Kathryn and I love TACOS!");
	}
}